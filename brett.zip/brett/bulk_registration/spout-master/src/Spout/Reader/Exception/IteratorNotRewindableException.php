<?php

namespace Box\Spout\Reader\Exception;

/**
 * Class IteratorNotRewindableException
 *
 * @api
 * @package Box\Spout\Reader\Exception
 */
class IteratorNotRewindableException extends ReaderException
{
}
