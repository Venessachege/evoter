<html>
    <head><title>upload</title></head>
<body>
<form  action="upload.php" method="POST"
           enctype="multipart/form-data">
 
  <input type="file"  name="file" >
  
 <input type= "submit" value ="Upload" >
  
</form>
</body>
</html>